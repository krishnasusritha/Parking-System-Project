package edu.du.ict4315.parking;

import com.google.inject.AbstractModule;

public class ParkingModule extends AbstractModule {
	  @Override 
	  protected void configure() {

	  }
	}
